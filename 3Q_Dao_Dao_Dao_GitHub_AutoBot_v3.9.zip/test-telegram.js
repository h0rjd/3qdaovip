/**
 * Telegram Bot & Interactive Control Panel Verification Script
 * Gửi bảng điều khiển nút bấm trực tiếp (Inline Keyboard) về Telegram theo config.json
 */

const fs = require('fs');
const path = require('path');
const { buildTelegramKeyboard } = require('./runner');

const cfgPath = path.join(__dirname, 'config.json');
const config = fs.existsSync(cfgPath) ? JSON.parse(fs.readFileSync(cfgPath, 'utf8')) : {};
const tele = config.telegram || {};
const acc = (config.accounts && config.accounts[0]) || config.account || {};

const token = process.env.TELEGRAM_BOT_TOKEN || tele.bot_token;
const chatId = process.env.TELEGRAM_CHAT_ID || tele.chat_id;

async function testTelegram() {
    if (!token || !chatId) {
        console.error('[TelegramTest] ❌ Thiếu bot_token hoặc chat_id trong config.json!');
        process.exit(1);
    }

    const nowVn = new Date(Date.now() + 7 * 3600 * 1000).toISOString().replace('T', ' ').substring(0, 19);
    const html = [
        `<b>🎛️ [3Q AUTOBOT v3.9.32] BẢNG ĐIỀU KHIỂN TRỰC TUYẾN 24/7</b>`,
        `━━━━━━━━━━━━━━━━━━`,
        `👤 <b>Tài khoản:</b> <code>${acc.email || 'dungby5@gmail.com'}</code>`,
        `🌐 <b>Máy chủ:</b> ${acc.server_name || 'Tam Quốc S6'}`,
        `💎 <b>Chế độ chính:</b> Farm KNB Giải Cứu Gia Viên (+50 KNB/lượt)`,
        `📱 <b>Nhường máy khi vào ĐT:</b> BẬT (Tự dừng ${config.settings ? config.settings.yield_wait_minutes || 15 : 15} phút rồi tự chạy tiếp)`,
        `📡 <b>Chu kỳ báo cáo:</b> Mỗi ${tele.report_interval_min || 30} phút`,
        `🕒 <b>Cập nhật:</b> ${nowVn} (GMT+7)`,
        `━━━━━━━━━━━━━━━━━━`,
        `💡 <i>Khi Bot đang chạy trên GitHub Actions, anh chỉ cần <b>bấm trực tiếp các nút bên dưới ngay trên Telegram</b> để Bật/Tắt <b>Vượt Ải, Long Mạch, Leo Tháp, Gia Viên...</b> tức thì (1–2 giây) mà không cần dừng hay chạy lại GitHub!</i>`
    ].join('\n');

    console.log(`[TelegramTest] Đang gửi Bảng Điều Khiển Nút Bấm tới Chat ID: ${chatId}...`);
    const resp = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            chat_id: String(chatId),
            text: html,
            parse_mode: 'HTML',
            reply_markup: buildTelegramKeyboard({ isYielding: false })
        })
    });

    const res = await resp.json();
    if (res && res.ok) {
        console.log('[TelegramTest] ✅ Đã gửi Bảng Điều Khiển Telegram THÀNH CÔNG! Message ID:', res.result.message_id);
    } else {
        console.error('[TelegramTest] ❌ Gửi Telegram thất bại:', res);
        process.exit(1);
    }
}

if (require.main === module) {
    testTelegram();
}

module.exports = { testTelegram };
