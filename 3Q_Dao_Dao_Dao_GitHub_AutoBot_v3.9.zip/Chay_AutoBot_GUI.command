#!/bin/bash
# 3Q Đào Đào Đào - One-Click Launcher cho macOS (GUI Control Center v3.9.32)
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

echo "=================================================================="
echo "🐉 KHỞI ĐỘNG 3Q ĐÀO ĐÀO ĐÀO - AUTOBOT GUI v3.9.32 (24/7 FARM KNB)"
echo "🖥️  Bảng điều khiển GUI: http://127.0.0.1:3939"
echo "=================================================================="

if [ ! -d "node_modules" ]; then
    echo "📦 Đang cài đặt thư viện trình duyệt lần đầu..."
    npm install --no-audit --no-fund
fi

node runner.js
