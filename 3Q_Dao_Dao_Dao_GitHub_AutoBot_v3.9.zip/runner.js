/**
 * 3Q Đào Đào Đào - Cloud & Local Headless Runner v3.9.32 (Puppeteer + GitHub Actions + Interactive Telegram Control)
 * Tích hợp:
 * - Treo liên tục 24/7 trên GitHub Actions (tự động nối phiên không ngắt quãng)
 * - Đọc cấu hình trực tiếp từ config.json & tự động Hot-Reload nếu sửa config.json trên GitHub khi đang chạy
 * - Điều khiển Bật/Tắt mọi tính năng (Vượt Ải, Long Mạch, Farm KNB, Leo Tháp, Gia Viên...) TRỰC TIẾP QUA NÚT BẤM TELEGRAM khi đang chạy
 * - Cơ chế Nhường Máy thông minh (yield_on_kick: tự dừng 15 phút khi có login từ Điện thoại, xong tự chạy tiếp; hoặc bấm nút Chạy Ngay trên Telegram)
 * - Báo cáo tiến trình & thống kê KNB định kỳ về Telegram (kèm ảnh chụp màn hình)
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// ============================================================================
// 1. ĐỌC CẤU HÌNH TỪ CONFIG.JSON & BIẾN MÔI TRƯỜNG
// ============================================================================
const CONFIG_PATH = path.join(__dirname, 'config.json');
let rawConfig = {};
try {
    if (fs.existsSync(CONFIG_PATH)) {
        rawConfig = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
    }
} catch (err) {
    console.error(`[Config] ⚠️ Lỗi đọc config.json: ${err.message}`);
}

const primaryAccount = (Array.isArray(rawConfig.accounts) && rawConfig.accounts[0]) || rawConfig.account || {};
const cfgSettings = rawConfig.settings || {};
const cfgTelegram = rawConfig.telegram || {};
const cfgToggles = rawConfig.toggles || {};
const cfgIntervals = rawConfig.intervals || {};
const cfgTreasureFilter = rawConfig.treasure_filter || {};

const isGitHubActions = process.env.GITHUB_ACTIONS === 'true';
const forceHeadless = isGitHubActions || process.env.HEADLESS === 'true' || cfgSettings.show_browser === false;

const CONFIG = {
    email: process.env.JOYPLAY_EMAIL || primaryAccount.email || 'dungby5@gmail.com',
    password: process.env.JOYPLAY_PASSWORD || primaryAccount.password || 'ntdung12',
    server: process.env.GAME_SERVER || primaryAccount.server_name || 'Tam Quốc S6',
    durationMinutes: parseInt(process.env.RUN_DURATION_MINUTES || '330', 10),
    headless: forceHeadless,
    settings: {
        show_browser: !forceHeadless,
        skip_ads: cfgSettings.skip_ads !== undefined ? !!cfgSettings.skip_ads : true,
        skip_battle: cfgSettings.skip_battle !== undefined ? !!cfgSettings.skip_battle : true,
        speed_hack: Number(cfgSettings.speed_hack) || 2,
        yield_on_kick: cfgSettings.yield_on_kick !== undefined ? !!cfgSettings.yield_on_kick : true,
        yield_wait_minutes: Number(cfgSettings.yield_wait_minutes) || 15
    },
    telegram: {
        bot_token: process.env.TELEGRAM_BOT_TOKEN || cfgTelegram.bot_token || '',
        chat_id: process.env.TELEGRAM_CHAT_ID || cfgTelegram.chat_id || '',
        report_interval_min: parseInt(process.env.TELEGRAM_REPORT_INTERVAL_MIN || cfgTelegram.report_interval_min || '30', 10)
    },
    toggles: Object.assign({
        auto_stage: false,
        auto_tower: false,
        auto_hero_up: false,
        auto_dispatch: false,
        auto_host: false,
        auto_rescue_knb: true,
        auto_star_up: false,
        auto_manual: false,
        auto_rank: true,
        auto_treasure: false,
        auto_arena: true,
        auto_afk: true,
        auto_defjz: true,
        auto_yyzq_core: true,
        auto_split_purple_shard: true,
        auto_touhu: true,
        auto_feidao: false,
        auto_hongbao: false,
        auto_act_task: true,
        auto_daily_rewards: true,
        auto_free_lottery: true,
        auto_longmach: false,
        auto_skvs: true,
        auto_guild_mine: true,
        mod_skin: true,
        mod_headframe_title: true
    }, cfgToggles),
    intervals: cfgIntervals,
    treasure_filter: cfgTreasureFilter,
    gameUrl: 'https://yxkp-cdn.anhhung3q.com/web-mobile/index.html',
    playPortalUrl: 'https://3qdao.joyplay.vn/play',
    productId: 'b21anhhung',
    screenshotDir: path.join(__dirname, 'screenshots'),
    logFile: path.join(__dirname, 'bot.log')
};

const TOGGLE_LABELS = {
    auto_rescue_knb: '💎 Farm 50 KNB',
    auto_stage: '⚔️ Vượt Ải',
    auto_longmach: '🎲 Long Mạch',
    auto_tower: '🏰 Leo Tháp',
    auto_host: '🏡 Gia Viên',
    auto_defjz: '🛡️ Bí Cảnh',
    auto_guild_mine: '🌾 Mỏ Bang',
    auto_touhu: '🎯 Thần Xạ',
    auto_feidao: '🗡️ Phi Kiếm',
    auto_hongbao: '🧧 Lì Xì',
    auto_treasure: '⛏️ Đào Bảo',
    auto_dispatch: '🗺️ Phái Tướng',
    auto_arena: '🏆 Đấu Trường',
    auto_rank: '👑 Bái 7 BXH',
    auto_skvs: '🐯 Long Hổ',
    auto_daily_rewards: '🎁 Quà Ngày',
    auto_free_lottery: '🎰 Quay Free',
    auto_split_purple_shard: '🧩 Tách Mảnh'
};

if (!fs.existsSync(CONFIG.screenshotDir)) {
    fs.mkdirSync(CONFIG.screenshotDir, { recursive: true });
}

function writeLog(msg) {
    const now = new Date();
    const vnTime = new Date(now.getTime() + 7 * 3600 * 1000).toISOString().replace('T', ' ').substring(0, 19);
    const line = `[${vnTime}] ${msg}\n`;
    process.stdout.write(line);
    try {
        fs.appendFileSync(CONFIG.logFile, line, 'utf8');
    } catch (e) {}
}

function formatNum(n) {
    const num = Number(n || 0);
    return isNaN(num) ? String(n || 0) : num.toLocaleString('en-US');
}

function saveConfigToDisk() {
    try {
        rawConfig.settings = Object.assign(rawConfig.settings || {}, CONFIG.settings);
        rawConfig.toggles = Object.assign(rawConfig.toggles || {}, CONFIG.toggles);
        fs.writeFileSync(CONFIG_PATH, JSON.stringify(rawConfig, null, 2), 'utf8');
    } catch (e) {}
}

// ============================================================================
// 2. HỆ THỐNG BÁO CÁO & ĐIỀU KHIỂN TỪ XA QUA TELEGRAM (INLINE KEYBOARD)
// ============================================================================
function buildTelegramKeyboard(sessionState) {
    const t = CONFIG.toggles;
    const isYielding = !!(sessionState && sessionState.isYielding);
    const btn = (key) => ({
        text: `${t[key] ? '✅' : '❌'} ${TOGGLE_LABELS[key] || key}`,
        callback_data: `toggle:${key}`
    });

    return {
        inline_keyboard: [
            [btn('auto_rescue_knb'), btn('auto_stage')],
            [btn('auto_longmach'), btn('auto_tower')],
            [btn('auto_host'), btn('auto_defjz')],
            [btn('auto_guild_mine'), btn('auto_touhu')],
            [btn('auto_feidao'), btn('auto_hongbao')],
            [btn('auto_treasure'), btn('auto_dispatch')],
            [
                { text: '📸 Xem Ảnh & Báo Cáo Ngay', callback_data: 'action:report_now' },
                isYielding
                    ? { text: '▶️ Chạy Lại Ngay (Bỏ Chờ)', callback_data: 'action:resume_now' }
                    : { text: `⏸️ Nghỉ ${CONFIG.settings.yield_wait_minutes || 15}p Nhường Máy`, callback_data: 'action:pause_15m' }
            ]
        ]
    };
}

async function sendTelegramMessage(htmlText, photoPath = null, sessionState = null) {
    const token = CONFIG.telegram.bot_token;
    const chatId = CONFIG.telegram.chat_id;
    if (!token || !chatId) return false;

    const replyMarkup = buildTelegramKeyboard(sessionState);

    try {
        if (photoPath && fs.existsSync(photoPath) && typeof FormData !== 'undefined' && typeof Blob !== 'undefined') {
            try {
                const fileBuf = fs.readFileSync(photoPath);
                const form = new FormData();
                form.append('chat_id', String(chatId));
                form.append('caption', htmlText);
                form.append('parse_mode', 'HTML');
                form.append('reply_markup', JSON.stringify(replyMarkup));
                form.append('photo', new Blob([fileBuf], { type: 'image/png' }), path.basename(photoPath));

                const photoResp = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, {
                    method: 'POST',
                    body: form
                });
                const photoRes = await photoResp.json();
                if (photoRes && photoRes.ok) {
                    writeLog(`[Telegram] ✅ Đã gửi báo cáo kèm ảnh & bảng điều khiển về Telegram!`);
                    return true;
                }
            } catch (ePhoto) {
                writeLog(`[Telegram] ⚠️ Gửi ảnh thất bại (${ePhoto.message}), chuyển sang gửi tin nhắn văn bản...`);
            }
        }

        const resp = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chat_id: String(chatId),
                text: htmlText,
                parse_mode: 'HTML',
                disable_web_page_preview: true,
                reply_markup: replyMarkup
            })
        });
        const res = await resp.json();
        if (res && res.ok) {
            writeLog(`[Telegram] ✅ Đã gửi báo cáo & bảng điều khiển về Telegram thành công!`);
            return true;
        } else {
            writeLog(`[Telegram] ⚠️ API trả về lỗi: ${JSON.stringify(res)}`);
            return false;
        }
    } catch (err) {
        writeLog(`[Telegram] ⚠️ Lỗi kết nối Telegram: ${err.message}`);
        return false;
    }
}

function buildTelegramReportHtml(title, stats, sessionState, extraNote = '') {
    const st = stats || {};
    const nowVn = new Date(Date.now() + 7 * 3600 * 1000).toISOString().replace('T', ' ').substring(0, 19);
    const elapsedMin = Math.max(1, Math.round((Date.now() - sessionState.startTime) / 60000));
    const remainMin = Math.max(0, Math.round((sessionState.endTime - Date.now()) / 60000));

    const curJade = Number(st.jade || 0);
    const startJade = sessionState.initialJade !== null ? sessionState.initialJade : curJade;
    const deltaJade = curJade - startJade;
    const deltaJadeStr = deltaJade >= 0 ? `+${formatNum(deltaJade)}` : formatNum(deltaJade);

    const totalRescuedCount = (sessionState.baseRescuedCount || 0) + Number(st.rescuedCount || 0);
    const totalRescuedKnb = (sessionState.baseRescuedKnb || 0) + Number(st.rescuedKnbTotal || 0);
    const inspectedHomes = (sessionState.baseInspectedHomes || 0) + Number(st.inspectedHomesCount || 0);

    const basePow = Number(st.basePower || st.power || 0);
    const curPow = Number(st.power || 0);
    const powText = (basePow > curPow && curPow > 0)
        ? `${formatNum(basePow)} <i>(Đội dò: ${formatNum(curPow)})</i>`
        : `${formatNum(basePow || curPow)}`;

    const activeFeatures = [];
    for (const [k, label] of Object.entries(TOGGLE_LABELS)) {
        if (CONFIG.toggles[k]) activeFeatures.push(label);
    }

    let lines = [
        `<b>${title}</b>`,
        `━━━━━━━━━━━━━━━━━━`,
        `👤 <b>Nhân vật:</b> ${st.roleName || 'Đang tải...'} (Lv.${st.level || '?'})`,
        `🌐 <b>Máy chủ:</b> ${CONFIG.server} (<code>${CONFIG.email}</code>)`,
        `⚔️ <b>Lực chiến:</b> ${powText}`,
        `🏰 <b>Tiến độ:</b> Ải ${st.stage || '--'} | Tháp ${st.towerFloor || '--'}`,
        `💰 <b>KNB hiện có:</b> <b>${formatNum(curJade)} KNB</b> (<code>${deltaJadeStr} KNB</code>)`,
        `🪙 <b>Vàng:</b> ${formatNum(st.gold || 0)} | ⛏️ <b>Xẻng:</b> ${formatNum(st.shovels || 0)}`,
        `━━━━━━━━━━━━━━━━━━`,
        `💎 <b>THỐNG KÊ FARM KNB GIẢI CỨU:</b>`,
        `• <b>Giải cứu thành công:</b> <b>${totalRescuedCount} lượt</b> (<b>+${formatNum(totalRescuedKnb)} KNB</b>)`,
        `• <b>Gia viên đã dò:</b> ${formatNum(inspectedHomes)} nhà`,
        `━━━━━━━━━━━━━━━━━━`,
        `⚙️ <b>Đang bật:</b> ${activeFeatures.join(', ') || 'Tạm dừng'}`,
        `⏱️ <b>Đã treo:</b> ${elapsedMin}p (Còn ${remainMin}p trong phiên • Tự nối 24/7)`,
        `🕒 <b>Cập nhật:</b> ${nowVn} (GMT+7)`,
        `💡 <i>Bấm trực tiếp các nút bên dưới để Bật/Tắt tính năng ngay khi đang chạy!</i>`
    ];

    if (extraNote) {
        lines.push(`━━━━━━━━━━━━━━━━━━`);
        lines.push(extraNote);
    }

    return lines.join('\n');
}

async function applyTogglesToLivePage(page, changedKey = null) {
    if (!page || page.isClosed()) return false;
    try {
        const merged = Object.assign({}, CONFIG.settings, CONFIG.toggles);
        await page.evaluate((t, key) => {
            try {
                localStorage.setItem("3qdao_bot_settings", JSON.stringify(t));
            } catch (e) {}
            if (!window.AutoBot) return;
            window.AutoBot.setToggles(t);
            if (typeof window.AutoBot.setSpeed === 'function' && t.speed_hack) {
                window.AutoBot.setSpeed(t.speed_hack);
            }
            if (key && t[key]) {
                if (key === 'auto_stage' && typeof window.AutoBot.runAutoStageSmart === 'function') {
                    window.AutoBot.runAutoStageSmart();
                } else if (key === 'auto_longmach' && typeof window.AutoBot.runAutoLongMachSmart === 'function') {
                    window.AutoBot.runAutoLongMachSmart();
                } else if (key === 'auto_rescue_knb' && typeof window.AutoBot.runAutoRescueKnbSmart === 'function') {
                    window.AutoBot.runAutoRescueKnbSmart();
                } else if (key === 'auto_tower' && typeof window.AutoBot.runAutoTowerSmart === 'function') {
                    window.AutoBot.runAutoTowerSmart();
                } else if (key === 'auto_host' && typeof window.AutoBot.runAutoHostSmart === 'function') {
                    window.AutoBot.runAutoHostSmart();
                } else if (key === 'auto_defjz' && typeof window.AutoBot.runAutoDefJzSmart === 'function') {
                    window.AutoBot.runAutoDefJzSmart();
                } else if (key === 'auto_feidao' && typeof window.AutoBot.runAutoFeiDaoSmart === 'function') {
                    window.AutoBot.runAutoFeiDaoSmart();
                }
            }
        }, merged, changedKey);
        return true;
    } catch (e) {
        writeLog(`[LiveSync] ⚠️ Không thể áp dụng trực tiếp vào trang: ${e.message}`);
        return false;
    }
}

// ============================================================================
// 3. BỘ LẮNG NGHE LỆNH ĐIỀU KHIỂN TELEGRAM & HOT-RELOAD GITHUB CONFIG
// ============================================================================
function startTelegramCommandPoller(sessionState, getActivePage) {
    const token = CONFIG.telegram.bot_token;
    const allowedChatId = String(CONFIG.telegram.chat_id || '');
    if (!token || !allowedChatId) return () => {};

    let stopped = false;
    let lastUpdateId = 0;

    // Khởi tạo offset ban đầu để bỏ qua các tin nhắn cũ trước khi phiên chạy bắt đầu
    (async () => {
        try {
            const initResp = await fetch(`https://api.telegram.org/bot${token}/getUpdates?offset=-1&limit=1`);
            const initData = await initResp.json();
            if (initData && initData.ok && Array.isArray(initData.result) && initData.result.length > 0) {
                lastUpdateId = initData.result[initData.result.length - 1].update_id;
            }
        } catch (e) {}

        while (!stopped) {
            try {
                const resp = await fetch(`https://api.telegram.org/bot${token}/getUpdates?offset=${lastUpdateId + 1}&timeout=2`);
                const data = await resp.json();
                if (data && data.ok && Array.isArray(data.result)) {
                    for (const upd of data.result) {
                        lastUpdateId = Math.max(lastUpdateId, upd.update_id);

                        // 1. Xử lý khi người dùng bấm nút trên bảng điều khiển Inline Keyboard
                        if (upd.callback_query) {
                            const cq = upd.callback_query;
                            const fromChatId = String((cq.message && cq.message.chat && cq.message.chat.id) || '');
                            if (fromChatId && fromChatId !== allowedChatId) continue;

                            const actionData = String(cq.data || '');
                            if (actionData.startsWith('toggle:')) {
                                const key = actionData.split(':')[1];
                                if (key && CONFIG.toggles[key] !== undefined) {
                                    CONFIG.toggles[key] = !CONFIG.toggles[key];
                                    const newVal = CONFIG.toggles[key];
                                    const label = TOGGLE_LABELS[key] || key;
                                    saveConfigToDisk();

                                    const page = getActivePage();
                                    await applyTogglesToLivePage(page, key);

                                    writeLog(`🎛️ [Telegram Remote] Đã chuyển đổi [${label}] -> ${newVal ? 'BẬT' : 'TẮT'}`);

                                    // Phản hồi popup trên màn hình Telegram của điện thoại
                                    try {
                                        await fetch(`https://api.telegram.org/bot${token}/answerCallbackQuery`, {
                                            method: 'POST',
                                            headers: { 'Content-Type': 'application/json' },
                                            body: JSON.stringify({
                                                callback_query_id: cq.id,
                                                text: `⚡ Đã ${newVal ? 'BẬT ✅' : 'TẮT ❌'} ${label}!`,
                                                show_alert: false
                                            })
                                        });
                                    } catch (e) {}

                                    // Cập nhật trạng thái nút bấm ngay trên tin nhắn Telegram
                                    if (cq.message && cq.message.message_id) {
                                        try {
                                            await fetch(`https://api.telegram.org/bot${token}/editMessageReplyMarkup`, {
                                                method: 'POST',
                                                headers: { 'Content-Type': 'application/json' },
                                                body: JSON.stringify({
                                                    chat_id: fromChatId,
                                                    message_id: cq.message.message_id,
                                                    reply_markup: buildTelegramKeyboard(sessionState)
                                                })
                                            });
                                        } catch (e) {}
                                    }
                                }
                            } else if (actionData === 'action:report_now') {
                                try {
                                    await fetch(`https://api.telegram.org/bot${token}/answerCallbackQuery`, {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify({
                                            callback_query_id: cq.id,
                                            text: '📸 Đang chụp màn hình và gửi báo cáo mới nhất...'
                                        })
                                    });
                                } catch (e) {}

                                const page = getActivePage();
                                const snapPath = path.join(CONFIG.screenshotDir, 'latest.png');
                                if (page && !page.isClosed()) {
                                    try {
                                        const stNow = await page.evaluate(() => window.AutoBot ? window.AutoBot.updateStats() : null);
                                        if (stNow) sessionState.lastKnownStats = stNow;
                                        await page.screenshot({ path: snapPath });
                                    } catch (e) {}
                                }
                                const html = buildTelegramReportHtml(
                                    '📸 BÁO CÁO TRẠNG THÁI TỨC THÌ (THEO YÊU CẦU)',
                                    sessionState.lastKnownStats,
                                    sessionState,
                                    sessionState.isYielding
                                        ? '⏸️ <i>Bot hiện đang trong thời gian tạm dừng nhường máy.</i>'
                                        : '🟢 <i>Bot đang hoạt động trực tuyến bình thường.</i>'
                                );
                                await sendTelegramMessage(html, fs.existsSync(snapPath) ? snapPath : null, sessionState);
                            } else if (actionData === 'action:pause_15m') {
                                sessionState.manualYieldRequested = true;
                                try {
                                    await fetch(`https://api.telegram.org/bot${token}/answerCallbackQuery`, {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify({
                                            callback_query_id: cq.id,
                                            text: `⏸️ Đang tạm dừng Bot ${CONFIG.settings.yield_wait_minutes || 15} phút để nhường máy...`
                                        })
                                    });
                                } catch (e) {}
                            } else if (actionData === 'action:resume_now') {
                                sessionState.forceResumeFromYield = true;
                                try {
                                    await fetch(`https://api.telegram.org/bot${token}/answerCallbackQuery`, {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify({
                                            callback_query_id: cq.id,
                                            text: '▶️ Đang kết nối vào lại game ngay lập tức!'
                                        })
                                    });
                                } catch (e) {}
                            }
                        }

                        // 2. Xử lý tin nhắn văn bản gửi tới Bot (/menu, /status, /pause, /resume)
                        if (upd.message && upd.message.text) {
                            const fromChatId = String((upd.message.chat && upd.message.chat.id) || '');
                            if (fromChatId !== allowedChatId) continue;
                            const txt = upd.message.text.trim().toLowerCase();

                            if (txt === '/menu' || txt === '/settings' || txt === '/start' || txt === '/status' || txt === '/report') {
                                const page = getActivePage();
                                const snapPath = path.join(CONFIG.screenshotDir, 'latest.png');
                                if (page && !page.isClosed()) {
                                    try {
                                        const stNow = await page.evaluate(() => window.AutoBot ? window.AutoBot.updateStats() : null);
                                        if (stNow) sessionState.lastKnownStats = stNow;
                                        await page.screenshot({ path: snapPath });
                                    } catch (e) {}
                                }
                                const html = buildTelegramReportHtml(
                                    '🎛️ BẢNG ĐIỀU KHIỂN TRỰC TUYẾN 3Q AUTOBOT v3.9.32',
                                    sessionState.lastKnownStats,
                                    sessionState
                                );
                                await sendTelegramMessage(html, fs.existsSync(snapPath) ? snapPath : null, sessionState);
                            } else if (txt === '/pause' || txt === '/nghi') {
                                sessionState.manualYieldRequested = true;
                            } else if (txt === '/resume' || txt === '/chay') {
                                sessionState.forceResumeFromYield = true;
                            }
                        }
                    }
                }
            } catch (ePoll) {}
            await new Promise(r => setTimeout(r, 2500));
        }
    })();

    return () => { stopped = true; };
}

// Kiểm tra nếu người dùng sửa file config.json trực tiếp trên web GitHub và bấm Commit
let lastGitConfigHash = '';
async function checkGitConfigHotReload(page, sessionState) {
    try {
        if (isGitHubActions) {
            try {
                execSync('git fetch -q origin', { cwd: __dirname, timeout: 8000, stdio: 'ignore' });
                const remoteCfgRaw = execSync('git show FETCH_HEAD:config.json', { cwd: __dirname, timeout: 5000 }).toString('utf8');
                const hash = crypto.createHash('md5').update(remoteCfgRaw).digest('hex');
                if (!lastGitConfigHash) {
                    lastGitConfigHash = hash;
                    return;
                }
                if (hash !== lastGitConfigHash) {
                    lastGitConfigHash = hash;
                    const parsed = JSON.parse(remoteCfgRaw);
                    const changes = [];
                    if (parsed.toggles) {
                        for (const [k, v] of Object.entries(parsed.toggles)) {
                            const boolV = !!v;
                            if (CONFIG.toggles[k] !== undefined && CONFIG.toggles[k] !== boolV) {
                                CONFIG.toggles[k] = boolV;
                                changes.push(`${TOGGLE_LABELS[k] || k}: <b>${boolV ? 'BẬT ✅' : 'TẮT ❌'}</b>`);
                            }
                        }
                    }
                    if (parsed.settings) {
                        if (parsed.settings.speed_hack !== undefined) CONFIG.settings.speed_hack = Number(parsed.settings.speed_hack) || 2;
                        if (parsed.settings.yield_on_kick !== undefined) CONFIG.settings.yield_on_kick = !!parsed.settings.yield_on_kick;
                        if (parsed.settings.yield_wait_minutes !== undefined) CONFIG.settings.yield_wait_minutes = Number(parsed.settings.yield_wait_minutes) || 15;
                    }
                    if (changes.length > 0) {
                        saveConfigToDisk();
                        await applyTogglesToLivePage(page);
                        writeLog(`🔄 [Git Hot-Reload] Đã tự động nạp thay đổi từ config.json trên GitHub: ${changes.join(', ')}`);
                        const html = buildTelegramReportHtml(
                            '🔄 ĐÃ CẬP NHẬT CẤU HÌNH MỚI TỪ GITHUB (HOT-RELOAD)',
                            sessionState.lastKnownStats,
                            sessionState,
                            `⚙️ <b>Thay đổi vừa áp dụng:</b>\n• ${changes.join('\n• ')}`
                        );
                        await sendTelegramMessage(html, null, sessionState);
                    }
                }
            } catch (eGit) {}
        }
    } catch (e) {}
}

// ============================================================================
// 4. XÁC THỰC JOYPLAY API & ĐỊNH VỊ MÁY CHỦ
// ============================================================================
async function authenticateJoyPlay(email, password) {
    writeLog(`[Auth] Đang gửi yêu cầu đăng nhập tài khoản: ${email}...`);
    const pwdMd5 = crypto.createHash('md5').update(password).digest('hex');

    const resp = await fetch('https://sdkapi.joygames.vn/auth/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)'
        },
        body: JSON.stringify({
            username: email,
            password: pwdMd5,
            isWebsite: true,
            productId: CONFIG.productId
        })
    });

    const res = await resp.json();
    if (res.status === 0 && res.data && res.data.accessToken) {
        writeLog(`[Auth] ✅ Đăng nhập JoyPlay thành công! Token ID: ${res.data.accessToken.substring(0, 24)}...`);
        return res.data.accessToken;
    } else {
        throw new Error(`Đăng nhập JoyPlay thất bại: ${JSON.stringify(res)}`);
    }
}

const SECRET_SALT = 'fH6CN6UDmt9jkCjuRRukUCfyj4joSIE3';

function ignoreCaseStringCompare(a, b) {
    const minLen = Math.min(a.length, b.length);
    for (let i = 0; i < minLen; i++) {
        const diff = a.charAt(i).toUpperCase().charCodeAt(0) - b.charAt(i).toUpperCase().charCodeAt(0);
        if (diff !== 0) return diff;
    }
    return a.length < b.length ? -1 : 1;
}

function getFlag(obj) {
    const keys = Object.keys(obj).filter(k => k !== 'flag').sort(ignoreCaseStringCompare);
    let str = '';
    keys.forEach(k => {
        if (obj[k] !== undefined && obj[k] !== null) {
            str += String(obj[k]);
        }
    });
    return crypto.createHash('md5').update(SECRET_SALT + str).digest('hex');
}

async function crawlDirectServerInfo(token, targetServer) {
    writeLog(`[Server] Đang cào danh sách máy chủ trực tiếp từ API game...`);
    try {
        const meResp = await fetch('https://sdkapi.joygames.vn/users/me', {
            headers: { 'Authorization': token, 'User-Agent': 'Mozilla/5.0' }
        });
        const meRes = await meResp.json();
        const userId = String(meRes.data.id);

        const nowSec = Math.floor(Date.now() / 1000);
        const loginPayload = {
            openId: userId,
            account: userId,
            password: token,
            uuid: '',
            token: '',
            account_type: 2,
            device: 'mac-runner',
            os: 3,
            time: nowSec,
            cid: 72
        };
        loginPayload.flag = getFlag(loginPayload);

        const loginResp = await fetch('https://yxkp-login.anhhung3q.com/login/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json;charset=UTF-8' },
            body: JSON.stringify(loginPayload)
        });
        const loginData = await loginResp.json();

        const allServers = [];
        let history = [];
        let maxPage = 3;
        for (let p = 0; p <= maxPage; p++) {
            const listPayload = {
                cid: 72,
                account: loginData.account || userId,
                token: loginData.token || '',
                page: p,
                time: Math.floor(Date.now() / 1000)
            };
            listPayload.flag = getFlag(listPayload);

            const listResp = await fetch('https://yxkp-login.anhhung3q.com/login/list', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json;charset=UTF-8' },
                body: JSON.stringify(listPayload)
            });
            const listData = await listResp.json();
            if (listData.code === 0) {
                if (typeof listData.tot_page === 'number' && listData.tot_page > maxPage) {
                    maxPage = Math.min(10, listData.tot_page);
                }
                if (p === 0 && Array.isArray(listData.history)) {
                    history = listData.history.map(h => Object.assign({}, h, {
                        id: h.id || h.sid,
                        sid: h.sid || h.id,
                        state: h.state !== undefined ? h.state : (h.srv_state || 0),
                        open_time: h.open_time || 0
                    }));
                }
                if (Array.isArray(listData.srv_list)) {
                    listData.srv_list.forEach(s => {
                        const norm = Object.assign({}, s, {
                            id: s.id || s.sid,
                            sid: s.sid || s.id,
                            page: s.page !== undefined ? s.page : p
                        });
                        if (!allServers.some(e => e.id === norm.id)) allServers.push(norm);
                    });
                }
            }
        }

        const targetStr = String(targetServer).toLowerCase().trim();
        const numMatch = targetStr.match(/\d+/);
        const targetNum = numMatch ? parseInt(numMatch[0], 10) : 6;
        const fullSid = targetNum < 1000 ? (20000 + targetNum) : targetNum;

        let targetObj = allServers.find(s =>
            s.id === fullSid ||
            s.id === targetNum ||
            (s.srv_name && s.srv_name.toLowerCase() === targetStr) ||
            (s.srv_name && s.srv_name.toLowerCase().includes(`s${targetNum}`))
        );
        if (!targetObj && history.length > 0) {
            targetObj = history.find(h => h.id === fullSid || h.sid === fullSid) || history[0];
        }
        if (targetObj && !allServers.some(e => e.id === targetObj.id)) {
            allServers.push(targetObj);
        }

        writeLog(`[Server] ✅ Cào thành công ${allServers.length} máy chủ! Đã định vị máy chủ mục tiêu: [${targetObj ? (targetObj.srv_name || targetObj.id) : targetServer}]`);
        return { userId, gameAccount: loginData.account, srvToken: loginData.token, targetObj, allServers, history };
    } catch (err) {
        writeLog(`[Server] ⚠️ Không cào được trực tiếp: ${err.message || err}`);
        return null;
    }
}

// ============================================================================
// 5. KHỞI TẠO PHIÊN TRÌNH DUYỆT & TIÊM AUTOBOT V3.9.32
// ============================================================================
async function launchAndEnterGame(sessionState) {
    const puppeteer = require('puppeteer');
    const accessToken = await authenticateJoyPlay(CONFIG.email, CONFIG.password);
    const serverInfo = await crawlDirectServerInfo(accessToken, CONFIG.server);

    if (serverInfo && serverInfo.history && serverInfo.history[0] && (!sessionState.lastKnownStats || !sessionState.lastKnownStats.roleName)) {
        const h0 = serverInfo.history[0];
        sessionState.lastKnownStats = {
            roleName: h0.name || '---',
            level: h0.lev || 0,
            power: Number(h0.fc || 0),
            basePower: Number(h0.fc || 0)
        };
    }

    writeLog(`[Browser] Đang khởi chạy Chromium (${CONFIG.headless ? 'Headless Cloud' : 'Hiển thị cửa sổ'})...`);
    const launchOpts = {
        headless: CONFIG.headless ? 'new' : false,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-accelerated-2d-canvas',
            '--no-first-run',
            '--no-zygote',
            '--disable-gpu',
            '--window-size=450,850'
        ],
        defaultViewport: {
            width: 450,
            height: 850,
            isMobile: true,
            hasTouch: true
        }
    };
    for (const candidate of ['/usr/bin/google-chrome-stable', '/usr/bin/google-chrome', '/usr/bin/chromium-browser', '/usr/bin/chromium']) {
        if (fs.existsSync(candidate)) {
            launchOpts.executablePath = candidate;
            writeLog(`[Browser] Sử dụng trình duyệt hệ thống: ${candidate}`);
            break;
        }
    }
    const browser = await puppeteer.launch(launchOpts);

    const page = await browser.newPage();
    await page.setUserAgent('Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148');

    await page.exposeFunction('pyOnBotLog', (entry) => {
        if (!entry || !entry.msg) return;
        writeLog(`[AutoBot] ${entry.time || ''} ${entry.msg}`);
    });

    page.on('pageerror', err => {
        writeLog(`[WebError] ${err.toString()}`);
    });

    writeLog(`[Nav] Điều hướng tới cổng game: ${CONFIG.gameUrl}...`);
    await page.goto(CONFIG.gameUrl, { waitUntil: 'domcontentloaded', timeout: 45000 });

    const mergedSettingsAndToggles = Object.assign({}, CONFIG.settings, CONFIG.toggles);

    writeLog("[Auth] Tiêm JoyPlay AccessToken, Cấu hình Bot & Dữ liệu máy chủ vào LocalStorage...");
    await page.evaluate((token, sInfo, botCfg) => {
        try {
            localStorage.setItem("joygamesAccessToken", token);
            localStorage.setItem("3qdao_bot_settings", JSON.stringify(botCfg));
            if (sInfo) {
                window.__PRELOADED_SERVER_INFO__ = sInfo;
            }
        } catch (e) {}
    }, accessToken, serverInfo, mergedSettingsAndToggles);

    writeLog("[Nav] Tải lại trang với xác thực đã lưu...");
    await page.reload({ waitUntil: 'networkidle2', timeout: 60000 });

    await page.screenshot({ path: path.join(CONFIG.screenshotDir, '01_page_loaded.png') });

    writeLog("[Game] Đang đợi Canvas và Engine tải gói tài nguyên...");
    await page.waitForSelector('#GameCanvas', { timeout: 45000 });

    let attempts = 0;
    let loginReady = false;
    while (attempts < 90) {
        attempts++;
        await new Promise(r => setTimeout(r, 2000));

        try {
            loginReady = await page.evaluate((sInfo, tick) => {
                function safeReq(name) {
                    if (typeof window.__require === "function") {
                        try {
                            const mod = window.__require(name);
                            if (mod) return mod[name] || mod.default || mod;
                        } catch (e) {}
                    }
                    if (window[name]) return window[name];
                    if (window.G_Mapping && window.G_Mapping[name]) return window.G_Mapping[name];
                    return null;
                }

                const sUtil = safeReq("LoadingServerUtil");
                const vm = safeReq("ViewManager");
                const mm = safeReq("ModelManager");
                const fcm = safeReq("FileCacheManager");

                if (fcm && typeof fcm.setStringForKey === "function") {
                    try { fcm.setStringForKey("showAgreement", "1", null, true); } catch (e) {}
                }

                if (sUtil && sInfo) {
                    if ((!sUtil.__serverList || sUtil.__serverList.length === 0) && Array.isArray(sInfo.allServers)) {
                        sUtil.__serverList = sInfo.allServers;
                    } else if (Array.isArray(sUtil.__serverList) && sInfo.targetObj) {
                        if (!sUtil.__serverList.some(x => x && x.id === sInfo.targetObj.id)) {
                            sUtil.__serverList.push(sInfo.targetObj);
                        }
                    }
                    if (sInfo.targetObj && typeof sUtil.updateSelectedServer === "function") {
                        try { sUtil.updateSelectedServer(sInfo.targetObj); } catch (e) {}
                    }
                }

                if (mm && mm.PlayerModel) {
                    const rInfo = typeof mm.PlayerModel.getRoleInfo === "function"
                        ? mm.PlayerModel.getRoleInfo()
                        : mm.PlayerModel.roleInfo;
                    if (rInfo && (rInfo.roleId || rInfo.rid || rInfo.name || rInfo.roleName || rInfo.level)) {
                        return "IN_GAME";
                    }
                }

                const loginView = (vm && typeof vm.getView === "function") ? vm.getView("LoginView") : null;
                if (loginView) {
                    const btnReady = !!(loginView.loginBtn && loginView.loginBtn.visible !== false);
                    const barDone = !loginView.barNode || loginView.barNode.visible === false;
                    if ((btnReady && barDone) || tick >= 25) {
                        return "LOGIN_VIEW";
                    }
                }
                return false;
            }, serverInfo, attempts);
        } catch (evalErr) {
            writeLog(`[Game] Đang chờ bundle khởi tạo... (${attempts}/90)`);
        }

        if (loginReady) break;
        if (attempts % 5 === 0) {
            writeLog(`[Game] Đang chờ tải tài nguyên đăng nhập... (${attempts}/90)`);
        }
    }

    writeLog(`[Game] Trạng thái màn hình đăng nhập: ${loginReady}`);
    await page.screenshot({ path: path.join(CONFIG.screenshotDir, '02_login_ready.png') });

    if (loginReady === "LOGIN_VIEW" || !loginReady) {
        writeLog(`[Server] Đang chọn máy chủ: [${CONFIG.server}] và kích hoạt Vào Game...`);
        const selectRes = await page.evaluate((targetSrv, sInfo) => {
            function safeReq(name) {
                if (typeof window.__require === "function") {
                    try {
                        const mod = window.__require(name);
                        if (mod) return mod[name] || mod.default || mod;
                    } catch (e) {}
                }
                if (window[name]) return window[name];
                if (window.G_Mapping && window.G_Mapping[name]) return window.G_Mapping[name];
                return null;
            }

            const sUtil = safeReq("LoadingServerUtil");
            const vm = safeReq("ViewManager");
            const fcm = safeReq("FileCacheManager");

            if (fcm && typeof fcm.setStringForKey === "function") {
                try { fcm.setStringForKey("showAgreement", "1", null, true); } catch (e) {}
            }

            const targetStr = String(targetSrv).toLowerCase().trim();
            const numMatch = targetStr.match(/\d+/);
            const targetNum = numMatch ? parseInt(numMatch[0], 10) : 6;
            const fullSid = targetNum < 1000 ? (20000 + targetNum) : targetNum;

            let found = null;
            if (sUtil) {
                if (sInfo && sInfo.targetObj) {
                    found = Object.assign({}, sInfo.targetObj, {
                        id: sInfo.targetObj.id || sInfo.targetObj.sid || fullSid,
                        sid: sInfo.targetObj.sid || sInfo.targetObj.id || fullSid,
                        state: sInfo.targetObj.state !== undefined ? sInfo.targetObj.state : 2,
                        open_time: 0
                    });
                }
                if (!found && Array.isArray(sUtil.__serverList) && sUtil.__serverList.length > 0) {
                    found = sUtil.__serverList.find(s =>
                        s.id === fullSid || s.sid === fullSid ||
                        s.id === targetNum || s.sid === targetNum ||
                        (s.srv_name && (s.srv_name.toLowerCase() === targetStr || s.srv_name.toLowerCase().includes(`s${targetNum}`) || s.srv_name.toLowerCase().includes(` ${targetNum}`))) ||
                        (s.name && (s.name.toLowerCase() === targetStr || s.name.toLowerCase().includes(`s${targetNum}`) || s.name.toLowerCase().includes(` ${targetNum}`)))
                    );
                }
                if (!found && typeof sUtil.getServerInfoBySid === "function") {
                    try { found = sUtil.getServerInfoBySid(fullSid) || sUtil.getServerInfoBySid(targetNum); } catch (e) {}
                }
                if (!found) {
                    found = { id: fullSid, sid: fullSid, srv_name: targetSrv, state: 2, page: 1, open_time: 0 };
                }
                if (!Array.isArray(sUtil.__serverList)) sUtil.__serverList = [];
                if (!sUtil.__serverList.some(x => x && x.id === found.id)) {
                    sUtil.__serverList.push(found);
                }
                if (typeof sUtil.updateSelectedServer === "function") {
                    try { sUtil.updateSelectedServer(found); } catch (e) {}
                }
            }

            let triggered = false;
            const loginView = vm && typeof vm.getView === "function" ? vm.getView("LoginView") : null;
            if (loginView) {
                try { loginView.checkHasAgree = function () { return true; }; } catch (e) {}
                if (typeof loginView.login_chooseServer === "function") {
                    try { loginView.login_chooseServer(); } catch (e) {}
                }
                if (typeof loginView.loginHandler === "function") {
                    try {
                        loginView.loginHandler();
                        triggered = true;
                    } catch (e) {}
                }
            }

            return {
                selectedServer: found ? (found.srv_name || found.name || found.id) : null,
                triggeredEnter: triggered
            };
        }, CONFIG.server, serverInfo);

        writeLog(`[Server] Kết quả chọn máy chủ: ${JSON.stringify(selectRes)}`);

        if (!selectRes.triggeredEnter) {
            writeLog("[Input] Click giả lập nút Vào Game trên Canvas...");
            await page.click('#GameCanvas', { offset: { x: 225, y: 650 } });
        }

        writeLog("[Game] Đang đợi vào sảnh chính...");
        let inGame = false;
        for (let i = 0; i < 45; i++) {
            await new Promise(r => setTimeout(r, 2000));
            try {
                inGame = await page.evaluate((retryLogin) => {
                    function safeReq(name) {
                        if (typeof window.__require === "function") {
                            try {
                                const mod = window.__require(name);
                                if (mod) return mod[name] || mod.default || mod;
                            } catch (e) {}
                        }
                        if (window[name]) return window[name];
                        if (window.G_Mapping && window.G_Mapping[name]) return window.G_Mapping[name];
                        return null;
                    }
                    const mm = safeReq("ModelManager");
                    if (mm && mm.PlayerModel) {
                        const rInfo = typeof mm.PlayerModel.getRoleInfo === "function"
                            ? mm.PlayerModel.getRoleInfo()
                            : mm.PlayerModel.roleInfo;
                        if (rInfo && (rInfo.roleId || rInfo.rid || rInfo.name || rInfo.roleName || rInfo.level)) {
                            return true;
                        }
                    }
                    if (retryLogin) {
                        const vm = safeReq("ViewManager");
                        const pUtils = safeReq("PlatformUtils");
                        const loginView = vm && typeof vm.getView === "function" ? vm.getView("LoginView") : null;
                        if (loginView && typeof loginView.loginHandler === "function") {
                            if (pUtils) pUtils.isLogining = false;
                            try { loginView.checkHasAgree = function () { return true; }; } catch (e) {}
                            try { loginView.loginHandler(); } catch (e) {}
                        }
                    }
                    return false;
                }, (i === 6 || i === 14 || i === 24));
            } catch (e) {}
            if (inGame) break;
        }

        if (!inGame) {
            writeLog("[Warning] Chưa nhận diện được PlayerModel, thử click tiếp tục...");
            await page.click('#GameCanvas', { offset: { x: 225, y: 700 } });
            await new Promise(r => setTimeout(r, 5000));
        }
    }

    const payloadFile = fs.existsSync(path.join(__dirname, 'injected_agent.js'))
        ? path.join(__dirname, 'injected_agent.js')
        : path.join(__dirname, 'bot-payload.js');
    writeLog(`[Bot] Đang nạp mã nguồn ${path.basename(payloadFile)} (AutoBot v3.9.32)...`);
    const botPayloadCode = fs.readFileSync(payloadFile, 'utf8');

    await page.evaluate((code, cfg) => {
        const script = document.createElement('script');
        script.textContent = code;
        document.body.appendChild(script);

        if (window.AutoBot) {
            const merged = Object.assign({}, cfg.settings, cfg.toggles);
            window.AutoBot.setToggles(merged);
            if (typeof window.AutoBot.setSpeed === 'function') {
                window.AutoBot.setSpeed(cfg.settings.speed_hack || 2);
            }
            if (typeof window.AutoBot.setSkipAds === 'function') {
                window.AutoBot.setSkipAds(cfg.settings.skip_ads !== false);
            }
            if (typeof window.AutoBot.setSkipBattle === 'function') {
                window.AutoBot.setSkipBattle(cfg.settings.skip_battle !== false);
            }
            if (typeof window.AutoBot.startScheduleLoop === 'function') {
                window.AutoBot.startScheduleLoop();
            }
        }
    }, botPayloadCode, { settings: CONFIG.settings, toggles: CONFIG.toggles });

    writeLog("[Bot] ✅ AutoBot v3.9.32 (Farm KNB Homestead Rescue Edition) đã kích hoạt!");
    await new Promise(r => setTimeout(r, 4000));

    const snapStart = path.join(CONFIG.screenshotDir, '03_bot_started.png');
    await page.screenshot({ path: snapStart });

    return { browser, page };
}

// ============================================================================
// 6. VÒNG LẶP GIÁM SÁT, NHƯỜNG MÁY 15P & ĐIỀU KHIỂN TRỰC TIẾP QUA TELEGRAM
// ============================================================================
async function run() {
    writeLog("====================================================================");
    writeLog("🚀 KHỞI ĐỘNG 3Q ĐÀO ĐÀO ĐÀO - CLOUD AUTOBOT v3.9.32 (24/7 FARM KNB & TELE CONTROL)");
    writeLog(`🎯 Tài khoản: ${CONFIG.email} | Máy chủ: ${CONFIG.server} | Thời lượng phiên: ${CONFIG.durationMinutes} phút`);
    writeLog(`📡 Báo cáo & Điều khiển Telegram: Mỗi ${CONFIG.telegram.report_interval_min} phút | Nhường máy khi vào ĐT: ${CONFIG.settings.yield_on_kick ? `BẬT (Nghỉ ${CONFIG.settings.yield_wait_minutes}p rồi tự chạy tiếp)` : 'TẮT'}`);
    writeLog("====================================================================");

    const startTime = Date.now();
    const endTime = startTime + (CONFIG.durationMinutes * 60 * 1000);
    const reportIntervalMs = Math.max(1, CONFIG.telegram.report_interval_min) * 60 * 1000;

    const sessionState = {
        startTime,
        endTime,
        initialJade: null,
        startupReported: false,
        lastReportTime: Date.now(),
        baseRescuedCount: 0,
        baseRescuedKnb: 0,
        baseInspectedHomes: 0,
        lastKnownStats: {},
        isYielding: false,
        manualYieldRequested: false,
        forceResumeFromYield: false
    };

    let activeBrowser = null;
    let activePage = null;

    // Khởi chạy bộ lắng nghe nút bấm điều khiển trực tiếp từ Telegram
    const stopPoller = startTelegramCommandPoller(sessionState, () => activePage);

    try {
        const session = await launchAndEnterGame(sessionState);
        activeBrowser = session.browser;
        activePage = session.page;

        let cycle = 0;

        while (Date.now() < endTime) {
            cycle++;
            await new Promise(r => setTimeout(r, 10000)); // Chu kỳ kiểm tra mỗi 10 giây

            // Kiểm tra Hot-Reload nếu anh sửa config.json trên GitHub mỗi 30 giây
            if (cycle % 3 === 0) {
                await checkGitConfigHotReload(activePage, sessionState);
            }

            if (!activePage || activePage.isClosed()) {
                writeLog("[Watchdog] Trang trình duyệt đã đóng, đang khởi tạo lại phiên...");
                try { if (activeBrowser) await activeBrowser.close(); } catch (e) {}
                const reSession = await launchAndEnterGame(sessionState);
                activeBrowser = reSession.browser;
                activePage = reSession.page;
                continue;
            }

            const mergedToggles = Object.assign({}, CONFIG.settings, CONFIG.toggles);
            let status = null;
            try {
                status = await activePage.evaluate(async (t) => {
                    if (window.AutoBot && typeof window.AutoBot.runSmartCycle === "function") {
                        return await window.AutoBot.runSmartCycle(t);
                    }
                    return null;
                }, mergedToggles);
            } catch (evalErr) {
                writeLog(`[Watchdog] ⚠️ Lỗi evaluate runSmartCycle: ${evalErr.message}`);
            }

            if (status && status.stats) {
                const st = status.stats;
                sessionState.lastKnownStats = st;

                if (sessionState.initialJade === null && Number(st.jade || 0) > 0) {
                    sessionState.initialJade = Number(st.jade);
                }

                // Gửi báo cáo khởi động lần đầu ngay khi tải xong dữ liệu nhân vật
                if (!sessionState.startupReported && st.roleName && st.roleName !== "Đang tải..." && Number(st.power || 0) > 0) {
                    sessionState.startupReported = true;
                    sessionState.lastReportTime = Date.now();
                    const startSnap = path.join(CONFIG.screenshotDir, '03_bot_started.png');
                    try { await activePage.screenshot({ path: startSnap }); } catch (e) {}
                    const html = buildTelegramReportHtml(
                        '🚀 3Q AUTOBOT v3.9.32 - ĐÃ VÀO GAME & BẮT ĐẦU TREO 24/7',
                        st,
                        sessionState,
                        '✅ <i>Anh có thể bấm trực tiếp các nút bên dưới để Bật/Tắt Vượt Ải, Long Mạch, Farm KNB... ngay khi đang chạy!</i>'
                    );
                    await sendTelegramMessage(html, startSnap, sessionState);
                }

                // Kiểm tra cơ chế Nhường Máy (khi có login từ ĐT hoặc khi bấm nút Nghỉ 15p trên Telegram)
                if ((status.kickedByOtherDevice && CONFIG.settings.yield_on_kick) || sessionState.manualYieldRequested) {
                    const isManual = sessionState.manualYieldRequested;
                    sessionState.manualYieldRequested = false;
                    sessionState.isYielding = true;
                    sessionState.forceResumeFromYield = false;

                    const waitMin = Math.max(1, Number(CONFIG.settings.yield_wait_minutes) || 15);
                    writeLog(`📱 [Nhường Máy] ${isManual ? 'Nhận lệnh tạm dừng từ Telegram' : 'Phát hiện tài khoản đăng nhập từ Điện thoại/PC'}! Tạm dừng ${waitMin} phút rồi tự động chạy tiếp...`);

                    // Lưu cộng dồn chỉ số Farm KNB trước khi đóng trình duyệt
                    sessionState.baseRescuedCount += Number(st.rescuedCount || 0);
                    sessionState.baseRescuedKnb += Number(st.rescuedKnbTotal || 0);
                    sessionState.baseInspectedHomes += Number(st.inspectedHomesCount || 0);

                    const kickHtml = buildTelegramReportHtml(
                        `📱 [NHƯỜNG MÁY] ĐÃ TẠM DỪNG ${waitMin} PHÚT`,
                        Object.assign({}, st, { rescuedCount: 0, rescuedKnbTotal: 0, inspectedHomesCount: 0 }),
                        sessionState,
                        isManual
                            ? `⏸️ <b>Đã tạm dừng Bot ${waitMin} phút theo lệnh trên Telegram!</b>\n👉 Bấm nút <b>"▶️ Chạy Lại Ngay"</b> bên dưới bất kỳ lúc nào nếu anh muốn Bot vào lại sớm hơn.`
                            : `⚠️ <b>Phát hiện anh vừa đăng nhập vào game trên Điện thoại!</b>\n🛑 Bot đã lập tức ngắt kết nối và tạm nghỉ <b>${waitMin} phút</b> để nhường máy.\n🔄 <i>Sau ${waitMin} phút Bot sẽ tự động đăng nhập lại và chạy tiếp (hoặc bấm nút "▶️ Chạy Lại Ngay" bên dưới khi anh chơi xong)!</i>`
                    );
                    await sendTelegramMessage(kickHtml, null, sessionState);

                    try {
                        await activeBrowser.close();
                    } catch (eClose) {}
                    activeBrowser = null;
                    activePage = null;

                    const waitEnd = Date.now() + (waitMin * 60 * 1000);
                    writeLog(`⏳ [Nhường Máy] Đang chờ ${waitMin} phút (hoặc lệnh Chạy Lại Ngay từ Telegram)...`);
                    while (Date.now() < waitEnd && Date.now() < endTime && !sessionState.forceResumeFromYield) {
                        await new Promise(r => setTimeout(r, 3000));
                    }

                    sessionState.isYielding = false;
                    if (Date.now() >= endTime) {
                        writeLog(`[Nhường Máy] Đã hết thời lượng phiên chạy hiện tại, chuyển sang phiên kế tiếp...`);
                        break;
                    }

                    writeLog(`🔄 [Nhường Máy] ${sessionState.forceResumeFromYield ? 'Nhận lệnh Chạy Lại Ngay từ Telegram' : `Đã hết ${waitMin} phút nhường máy`}! Đang đăng nhập lại...`);
                    sessionState.forceResumeFromYield = false;

                    const resumed = await launchAndEnterGame(sessionState);
                    activeBrowser = resumed.browser;
                    activePage = resumed.page;

                    const resumeSnap = path.join(CONFIG.screenshotDir, 'latest.png');
                    try { await activePage.screenshot({ path: resumeSnap }); } catch (e) {}
                    const resumeHtml = buildTelegramReportHtml(
                        `🔄 [TỰ ĐỘNG CHẠY TIẾP] BOT ĐÃ VÀO LẠI GAME`,
                        sessionState.lastKnownStats,
                        sessionState,
                        `✅ <i>AutoBot v3.9.32 đã đăng nhập lại thành công và tiếp tục chạy theo cài đặt hiện tại!</i>`
                    );
                    await sendTelegramMessage(resumeHtml, resumeSnap, sessionState);
                    sessionState.lastReportTime = Date.now();
                    continue;
                }

                // Log trạng thái ra console mỗi 30 giây
                if (cycle % 3 === 0) {
                    const remainMin = Math.max(0, Math.round((endTime - Date.now()) / 60000));
                    const totalRescued = sessionState.baseRescuedCount + Number(st.rescuedCount || 0);
                    const totalKnb = sessionState.baseRescuedKnb + Number(st.rescuedKnbTotal || 0);
                    writeLog(`[Trạng Thái] ${st.roleName || '---'} | Ải: ${st.stage || 1} | LC: ${formatNum(st.basePower || st.power)} | KNB: ${formatNum(st.jade)} | Giải cứu: ${totalRescued} lượt (+${totalKnb} KNB) | Còn: ${remainMin}p`);
                }

                // Chụp ảnh tiến trình mỗi 2 phút
                if (cycle % 12 === 0) {
                    const latestPath = path.join(CONFIG.screenshotDir, 'latest.png');
                    try {
                        await activePage.screenshot({ path: latestPath });
                    } catch (eSnap) {}
                }

                // Gửi báo cáo định kỳ về Telegram mỗi report_interval_min phút (mặc định 30 phút)
                if (Date.now() - sessionState.lastReportTime >= reportIntervalMs) {
                    sessionState.lastReportTime = Date.now();
                    const reportSnap = path.join(CONFIG.screenshotDir, 'latest.png');
                    try { await activePage.screenshot({ path: reportSnap }); } catch (e) {}
                    const periodicHtml = buildTelegramReportHtml(
                        `📊 BÁO CÁO ĐỊNH KỲ (${CONFIG.telegram.report_interval_min} PHÚT)`,
                        st,
                        sessionState,
                        `🟢 <i>Đang treo liên tục ổn định. Bấm nút bên dưới nếu anh muốn đổi tính năng!</i>`
                    );
                    await sendTelegramMessage(periodicHtml, reportSnap, sessionState);
                }
            }
        }

        // Kết thúc phiên chạy: chụp ảnh & gửi báo cáo chuyển phiên về Telegram
        writeLog("====================================================================");
        writeLog(`🏁 Đã hoàn thành chu kỳ phiên (${CONFIG.durationMinutes} phút) -> Tự động nối tiếp phiên mới 24/7!`);
        const finalSnap = path.join(CONFIG.screenshotDir, 'final.png');
        if (activePage && !activePage.isClosed()) {
            try { await activePage.screenshot({ path: finalSnap }); } catch (e) {}
        }
        const finalHtml = buildTelegramReportHtml(
            `🔄 CHUYỂN PHIÊN TỰ ĐỘNG 24/7 (${CONFIG.durationMinutes} PHÚT)`,
            sessionState.lastKnownStats,
            sessionState,
            `♻️ <i>Phiên hiện tại đã hoàn tất và GitHub Actions đang tự động khởi chạy phiên kế tiếp ngay lập tức!</i>`
        );
        await sendTelegramMessage(finalHtml, fs.existsSync(finalSnap) ? finalSnap : null, sessionState);
        writeLog("====================================================================");

    } catch (err) {
        writeLog(`[Fatal Error] Phiên chạy gặp sự cố: ${err.message}`);
        console.error(err);
        const errSnap = path.join(CONFIG.screenshotDir, 'error.png');
        if (activePage && !activePage.isClosed()) {
            try { await activePage.screenshot({ path: errSnap }); } catch (e) {}
        }
        const errHtml = buildTelegramReportHtml(
            `⚠️ CẢNH BÁO SỰ CỐ PHIÊN TREO`,
            sessionState.lastKnownStats,
            sessionState,
            `❌ <b>Chi tiết lỗi:</b> <code>${String(err.message || err).replace(/[<>&]/g, '')}</code>`
        );
        await sendTelegramMessage(errHtml, fs.existsSync(errSnap) ? errSnap : null, sessionState);
        process.exitCode = 1;
    } finally {
        stopPoller();
        if (activeBrowser) {
            writeLog("[Browser] Đóng Chromium...");
            try { await activeBrowser.close(); } catch (e) {}
        }
        writeLog("[Runner] Hoàn tất vòng đời runner.");
    }
}

if (require.main === module) {
    run();
}

module.exports = { run, sendTelegramMessage, buildTelegramKeyboard };
