/**
 * JoyPlay Authentication & Config Verification Script
 * Kiểm tra xác thực tài khoản JoyPlay API trực tiếp từ config.json / biến môi trường
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

let fileConfig = {};
try {
    const cfgPath = path.join(__dirname, 'config.json');
    if (fs.existsSync(cfgPath)) {
        fileConfig = JSON.parse(fs.readFileSync(cfgPath, 'utf8'));
    }
} catch (e) {}

const defaultAcc = (fileConfig.accounts && fileConfig.accounts[0]) || fileConfig.account || {};
const email = process.env.JOYPLAY_EMAIL || defaultAcc.email || 'dungby5@gmail.com';
const password = process.env.JOYPLAY_PASSWORD || defaultAcc.password || 'ntdung12';
const productId = 'b21anhhung';

async function testAuth() {
    console.log(`[AuthTest] Đang kiểm tra đăng nhập tài khoản: ${email}...`);
    const pwdMd5 = crypto.createHash('md5').update(password).digest('hex');

    try {
        const resp = await fetch('https://sdkapi.joygames.vn/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)'
            },
            body: JSON.stringify({
                username: email,
                password: pwdMd5,
                isWebsite: true,
                productId: productId
            })
        });

        const res = await resp.json();
        if (res.status === 0 && res.data && res.data.accessToken) {
            console.log(`[AuthTest] ✅ Đăng nhập THÀNH CÔNG!`);
            console.log(`[AuthTest] 🔑 AccessToken: ${res.data.accessToken.substring(0, 30)}...`);
            console.log(`[AuthTest] ⏳ Hạn dùng Token: ${res.data.accessTokenExpiredAt}`);

            const meResp = await fetch('https://sdkapi.joygames.vn/users/me', {
                headers: {
                    'Authorization': res.data.accessToken,
                    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)'
                }
            });
            const me = await meResp.json();
            if (me.status === 0 && me.data) {
                console.log(`[AuthTest] 👤 User ID: ${me.data.id}`);
                console.log(`[AuthTest] 📧 Email: ${me.data.email}`);
                console.log(`[AuthTest] 🏷️ Tên: ${me.data.name || me.data.username}`);
            }
            return res.data.accessToken;
        } else {
            console.error(`[AuthTest] ❌ Đăng nhập thất bại:`, res);
            process.exit(1);
        }
    } catch (e) {
        console.error(`[AuthTest] ❌ Lỗi kết nối API:`, e);
        process.exit(1);
    }
}

if (require.main === module) {
    testAuth();
}

module.exports = { testAuth };
