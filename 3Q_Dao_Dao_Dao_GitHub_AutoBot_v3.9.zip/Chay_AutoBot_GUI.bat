@echo off
chcp 65001 >nul
title 3Q Dao Dao Dao - AutoBot GUI Control Center v3.9.32
cd /d "%~dp0"

echo ==================================================================
echo 🐉 KHOI DONG 3Q DAO DAO DAO - AUTOBOT GUI v3.9.32 (24/7 FARM KNB)
echo 🖥️  Bang dieu khien GUI: http://127.0.0.1:3939
echo ==================================================================

if not exist "node_modules" (
    echo 📦 Dang cai dat thu vien trinh duyet lan dau...
    call npm install --no-audit --no-fund
)

node runner.js
pause
